var response = require("http/v3/response");

response.println("Hello World!");
response.flush();
response.close();